## tech stack:
```
typescript - react - redux - MUI - css - websocket - cypress - npm
```

## how to start:
```
cd PATH/TO/FOLDER

npm start
```

## how to build:
```
npm run build
```

#### other commands in `package.json` file.

## Notes:

#### for change IP addressess and other global variables, start with `Servises/Consts.ts`.