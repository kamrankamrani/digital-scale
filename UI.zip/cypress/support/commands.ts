/// <reference types="cypress" />

// Cypress.Commands.add("getByDataTest", (value) => {
//   return cy.get(`[data-test=${value}]`);
// });

// Cypress.Commands.add("confirmCaptcha", function () {

//   })

export {};
